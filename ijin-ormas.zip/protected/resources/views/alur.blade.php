@extends('layouts.main')
@section('content')
<section class="content">
  <div class="container no-padding">
      <div class="row">
          <div class="col-md-12">
            <div class="card">
              <h2>Alur</h2>
            </div>
          </div>
      </div>
  </div>
</section>
@endsection
