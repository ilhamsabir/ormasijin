<header class="clear-fix">
  <div class="header-content">
    <div class="container">
       <div class="row">
            <div class="header-content ">
              <img src="{{url('public/img/logo-ijinormas.png')}}" alt="">
            </div>
        </div>
    </div>
  </div>
</header>
