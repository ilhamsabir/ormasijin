<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Asap:400,700">
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
<link rel="stylesheet" href="{{ asset('public/css/vendor/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/css/vendor/bootstrap-datepicker.css') }}">
<link rel="stylesheet" href="{{ asset('public/css/vendor/select2.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/css/vendor/select2.theme.css') }}">
