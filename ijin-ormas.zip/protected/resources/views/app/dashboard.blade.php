@extends('app.layout')

@section('content')
<!-- Content Wrapper. Contains page content -->
<div class="container container-app">
	<div class="row">
		<div class="col-md-12">
			<ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
			<p>Dashboard</p>
		</div>
	</div>
</div>
@endsection
