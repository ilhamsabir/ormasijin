@extends('app.layout')
@section('content')

<div class="container container-app">
  <div id="cc"></div>
  <div class="row">
    <div class="col-md-12 card-table">
			<table id="data-ormas" class="display table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th style="background: rgb(79, 200, 212);">Nama</th>
                <th style="background: rgb(79, 200, 212);">Nama Organisasai</th>
                <th style="background: rgb(79, 200, 212);">Alamat Sekretariat</th>
                <th style="background: rgb(79, 200, 212);">Bidang Kegiatan</th>
                <th style="background: rgb(79, 200, 212);"></th>
            </tr>
        </thead>
    </table>
    </div>
    </div>
	</div>

@endsection
