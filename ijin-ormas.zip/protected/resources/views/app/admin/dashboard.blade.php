@extends('app.layout')

@section('content')
<div class="container container-app">
	<div class="row">
		<div class="col-md-12">

		</div>
	</div>
</div>
@endsection
