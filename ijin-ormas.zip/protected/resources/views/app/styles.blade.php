<!-- Bootstrap 3.3.6 -->
<link rel="stylesheet" href="{{ asset('public/css/vendor/bootstrap.min.css') }}">
<!-- jquery ui -->
<link rel="stylesheet" href="{{ asset('public/css/vendor/jquery-ui.min.css') }}">
<!-- font awesome -->
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"> -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
<!-- Date Picker -->
<link rel="stylesheet" href="{{ asset('/public/plugins/datepicker/datepicker3.css') }}">
<!-- Daterange picker -->
<link rel="stylesheet" href="{{ asset('/public/plugins/daterangepicker/daterangepicker.css') }}">

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css">
