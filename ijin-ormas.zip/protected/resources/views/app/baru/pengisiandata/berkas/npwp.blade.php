<div class="modal" id="modal-npwp">
  <div class="panel">
    <div class="panel-default">
      <div class="panel-body">

          <div class="from-group">
              <div class="fileUpload btn btn-default">
                <span>Click Here To Upload</span>
                <input type="file" class="upload" name="namafile" id="upload-npwp" accept=".pdf"/>
              </div>
           </div>

      </div>
    </div>
  </div>
  <div class="grid-content grid-npwp"></div>
  <div class="footer-modal">
    <button type="button" class="col-md-2 btn btn-md btn-default close-modal-npwp" name="button">Close</button>
    <button type="button" class="col-md-2 btn btn-md btn-primary close-modal-npwp" name="button">Select</button>
  </div>
</div>
