<div class="modal modal-logo">
  <div class="panel">
    <div class="panel-default">
      <div class="panel-body">

          <div class="from-group">
            <label for="" class="control-label">Upload lambang/logo</label>
              <div class="fileUpload btn btn-default">
                <span>Click Here To Upload</span>
                <input type="file" class="upload" name="namafile" id="input-logo" accept=".png, .jpg"/>
              </div>
           </div>

      </div>
    </div>
  </div>
  <div class="grid-content grid-logo"></div>
  <div class="footer-modal">
    <button type="button" class="col-md-2 btn btn-md btn-default close-modal-logo" name="button">Close</button>
    <button type="button" class="col-md-2 btn btn-md btn-primary close-modal-logo" name="button">Select</button>
  </div>
</div>
