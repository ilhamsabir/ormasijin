<div class="modal" id="modal-akte">
  <div class="panel">
    <div class="panel-default">
      <div class="panel-body">

          <div class="from-group">
              <div class="fileUpload btn btn-default">
                <span>Click Here To Upload</span>
                <input type="file" class="upload" name="namafile" id="upload-akte" accept=".pdf"/>
              </div>
           </div>

      </div>
    </div>
  </div>
  <div class="grid-content grid-akte"></div>
  <div class="footer-modal">
    <button type="button" class="col-md-2 btn btn-md btn-default close-modal-akte" name="button">Close</button>
    <button type="button" class="col-md-2 btn btn-md btn-primary close-modal-akte" name="button">Select</button>
  </div>
</div>
