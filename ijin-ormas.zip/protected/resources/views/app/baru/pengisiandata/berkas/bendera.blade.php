<div class="modal" id="modal-bendera">
  <div class="panel">
    <div class="panel-default">
      <div class="panel-body">

          <div class="from-group">            
              <div class="fileUpload btn btn-default">
                <span>Click Here To Upload</span>
                <input type="file" class="upload" name="namafile" id="upload-bendera" accept=".png, .jpg"/>
              </div>
           </div>

      </div>
    </div>
  </div>
  <div class="grid-content grid-bendera"></div>
  <div class="footer-modal">
    <button type="button" class="col-md-2 btn btn-md btn-default close-modal-bendera" name="button">Close</button>
    <button type="button" class="col-md-2 btn btn-md btn-primary close-modal-bendera" name="button">Select</button>
  </div>
</div>
