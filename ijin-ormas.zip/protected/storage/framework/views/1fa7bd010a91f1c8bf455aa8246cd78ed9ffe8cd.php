<script src="<?php echo e(asset('public/js/vendor/jquery-1.11.2.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/vendor/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/vendor/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/vendor/select2.min.js')); ?>"></script>
<!-- <script src="<?php echo e(asset('public/js/main.js')); ?>"></script> -->
<!-- <script src="<?php echo e(asset('public/js/main-init.js')); ?>"></script> -->

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
