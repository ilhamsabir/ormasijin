<table class="table table-striped">
<tbody>
<tr>
<td style="width: 199px;">Nama Pendiri</td>
<td style="width: 500px;">: <?php echo e($row->namapendiri); ?></td>
</tr>
<tr>
<td style="width: 199px;">Nama Penasehat</td>
<td style="width: 500px;">: <?php echo e($row->namapenasehat); ?></td>
</tr>
<tr>
<td style="width: 199px;">Nama Pembina</td>
<td style="width: 500px;">: <?php echo e($row->namapembina); ?></td>
</tr>
<tr>
<td style="width: 199px;"><strong>Ketua</strong></td>
<td style="width: 500px;"></td>
</tr>
<tr>
<td style="width: 199px;">Nama</td>
<td style="width: 500px;">: <?php echo e($row->namaketua); ?></td>
</tr>
<tr>
<td style="width: 199px;">Nama Panggilan</td>
<td style="width: 500px;">: <?php echo e($row->panggilanketua); ?></td>
</tr>
<tr>
<td style="width: 199px;">Tempat, Tanggal Lahir</td>
<td style="width: 500px;">:<?php echo e($row->tempatlahirketua); ?>,<?php echo e($row->tgllahirketua); ?></td>
</tr>
<tr>
<td style="width: 199px;">Jenis Kelamin</td>
<td style="width: 500px;">: <?php echo e($row->jeniskelaminketua); ?></td>
</tr>
<tr>
<td style="width: 199px;">Status Pernikahan</td>
<td style="width: 500px;">: <?php echo e($row->statusketua); ?></td>
</tr>
<tr>
<td style="width: 199px;">Agama</td>
<td style="width: 500px;">:<?php echo e($row->agamaketua); ?></td>
</tr>
<tr>
<td style="width: 199px;">Pendidikan</td>
<td style="width: 500px;">:<?php echo e($row->pendidikanketua); ?></td>
</tr>
<tr>
<td style="width: 199px;">No Handphone</td>
<td style="width: 500px;">:<?php echo e($row->nohpketua); ?></td>
</tr>
<tr>
<td style="width: 199px;">Email</td>
<td style="width: 500px;">:<?php echo e($row->emailketua); ?></td>
</tr>
<tr>
<td style="width: 199px;"><strong>Sekretaris</strong></td>
<td style="width: 500px;"></td>
</tr>
<tr>
<td style="width: 199px;">Nama</td>
<td style="width: 500px;">: <?php echo e($row->namasekretaris); ?></td>
</tr>
<tr>
<td style="width: 199px;">Nama Panggilan</td>
<td style="width: 500px;">: <?php echo e($row->panggilansekretaris); ?></td>
</tr>
<tr>
<td style="width: 199px;">Tempat, Tanggal Lahir</td>
<td style="width: 500px;">:<?php echo e($row->tempatlahirsekretaris); ?>,<?php echo e($row->tgllahirsekretaris); ?></td>
</tr>
<tr>
<td style="width: 199px;">Jenis Kelamin</td>
<td style="width: 500px;">: <?php echo e($row->jeniskelaminsekretaris); ?></td>
</tr>
<tr>
<td style="width: 199px;">Status Pernikahan</td>
<td style="width: 500px;">: <?php echo e($row->statussekretaris); ?></td>
</tr>
<tr>
<td style="width: 199px;">Agama</td>
<td style="width: 500px;">:<?php echo e($row->agamasekretaris); ?></td>
</tr>
<tr>
<td style="width: 199px;">Pendidikan</td>
<td style="width: 500px;">:<?php echo e($row->pendidikansekretaris); ?></td>
</tr>
<tr>
<td style="width: 199px;">No Handphone</td>
<td style="width: 500px;">:<?php echo e($row->nohpsekretaris); ?></td>
</tr>
<tr>
<td style="width: 199px;">Email</td>
<td style="width: 500px;">:<?php echo e($row->emailsekretaris); ?></td>
</tr>
<tr>
<td style="width: 199px;"><strong>Bendahara</strong></td>
<td style="width: 500px;"></td>
</tr>
<tr>
<td style="width: 199px;">Nama</td>
<td style="width: 500px;">: <?php echo e($row->namabendahara); ?></td>
</tr>
<tr>
<td style="width: 199px;">Nama Panggilan</td>
<td style="width: 500px;">: <?php echo e($row->panggilanbendahara); ?></td>
</tr>
<tr>
<td style="width: 199px;">Tempat, Tanggal Lahir</td>
<td style="width: 500px;">: <?php echo e($row->tempatlahirbendahara); ?>,<?php echo e($row->tgllahirbendahara); ?></td>
</tr>
<tr>
<td style="width: 199px;">Jenis Kelamin</td>
<td style="width: 500px;">: <?php echo e($row->jeniskelaminbendahara); ?></td>
</tr>
<tr>
<td style="width: 199px;">Status Pernikahan</td>
<td style="width: 500px;">: <?php echo e($row->statusbendahara); ?></td>
</tr>
<tr>
<td style="width: 199px;">Agama</td>
<td style="width: 500px;">: <?php echo e($row->agamabendahara); ?></td>
</tr>
<tr>
<td style="width: 199px;">Pendidikan</td>
<td style="width: 500px;">:<?php echo e($row->pendidikanbendahara); ?></td>
</tr>
<tr>
<td style="width: 199px;">No Handphone</td>
<td style="width: 500px;">:<?php echo e($row->nohpbendahara); ?></td>
</tr>
<tr>
<td style="width: 199px;">Email</td>
<td style="width: 500px;">:<?php echo e($row->emailbendahara); ?></td>
</tr>
</tbody>
</table>
