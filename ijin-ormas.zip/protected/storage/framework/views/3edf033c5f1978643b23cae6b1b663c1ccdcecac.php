<div id="sidebar-collapse" class="col-sm-3 sidebar">
	<ul class="nav menu margin-top">
		<li class="<?php echo e(Request::is('app/dashboard') ? 'active' : ''); ?>"><a href="<?php echo e(url('app/dashboard')); ?>"> <i class="fa fa-home"></i> Dashboard</a></li>
		<li role="presentation" class="divider"><i class="fa fa-clone"></i> Ijin Baru</li>
		<li role="presentation" class="divider"></li>
		<li class="<?php echo e(Request::is('app/registrasi/baru/pengisiandata') ? 'active' : ''); ?>">
			<a class="" href="<?php echo e(url('app/registrasi/baru/pengisiandata')); ?>">
				<i class="fa fa-angle-right"></i> Pengisian Data Organisasi
			</a>
		</li>
		<li class="<?php echo e(Request::is('app/registrasi/baru/verifikasilapangan') ? 'active' : ''); ?>">
			<a class="" href="<?php echo e(url('app/registrasi/baru/verifikasilapangan')); ?>">
				<i class="fa fa-angle-right"></i> Verfikasi Lapangan
			</a>
		</li>
		<li class="<?php echo e(Request::is('app/registrasi/baru/wawancara') ? 'active' : ''); ?>">
			<a class="" href="<?php echo e(url('app/registrasi/baru/wawancara')); ?>">
				<i class="fa fa-angle-right"></i> Penjadwalan Wawancara
			</a>
		</li>
		<li class="<?php echo e(Request::is('app/registrasi/baru/pengambilanskt') ? 'active' : ''); ?>">
			<a class="" href="<?php echo e(url('app/registrasi/baru/pengambilanskt')); ?>">
				<i class="fa fa-angle-right"></i> Pengambilan SKT
			</a>
		</li>

		<li role="presentation" class="divider"></li>
		<li class=""><a href="index.html"> <i class="fa fa-envelope-o"></i> Pesan</a></li>

</div><!--/.sidebar-->
