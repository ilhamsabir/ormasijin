<?php $__env->startSection('content'); ?>
<div class="container container-app">
  <div class="row">
    <div class="col-lg-12">
      <ol class="breadcrumb">
        <li><a href="#">Home</a></li>
        <li><a href="#">History</a></li>
        <li class="active">Data</li>
      </ol>
      <div id="history-user">
        
      </div>

      <!-- <ul class="timeline">
        <?php foreach($data as $key): ?>
          <?php if( $key->pesansuksesorganisasi >= 1 ): ?>
          <li>
            <div class="timeline-panel">
              <div class="timeline-body">
                <p><?php echo e($key->pesansuksesorganisasi); ?></p>
              </div>
            </div>
          </li>
          <?php elseif($key->pesangagalorganisasi >= 1): ?>
          <li>
            <div class="timeline-panel">
              <div class="timeline-body">
                <p><?php echo e($key->pesangagalorganisasi); ?></p>
              </div>
            </div>
          </li>
          <?php endif; ?>
        <?php endforeach; ?>
      </ul> -->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>