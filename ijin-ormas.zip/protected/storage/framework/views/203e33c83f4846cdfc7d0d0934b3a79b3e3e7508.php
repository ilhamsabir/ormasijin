<table class="table table-striped" style="height: 190px;" width="220">
  <tbody>
    <tr>
      <td>Nama</td>
      <td>: <?php echo e($row->name); ?></td>
    </tr>
    <tr>
      <td>Alamat</td>
      <td>: <?php echo e($row->alamat); ?></td>
    </tr>
    <tr>
      <td>No Telp</td>
      <td>: <?php echo e($row->no_tlp); ?></td>
    </tr>
    <tr>
      <td>Email</td>
      <td>: <?php echo e($row->email); ?></td>
    </tr>
  </tbody>
</table>
