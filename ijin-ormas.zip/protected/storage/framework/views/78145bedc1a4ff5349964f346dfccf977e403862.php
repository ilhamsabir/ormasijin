<?php $__env->startPush('styles'); ?>
	<!-- <link rel="stylesheet" href="<?php echo e(asset('public/css/report-charts.css')); ?>"> -->
<?php $__env->stopPush(); ?>

<div class="col-md-8">
  <div class="card__border--top">
    <div class="card-content">
      <div class="card-header-title">
        <h4>Monev ORMAS/LSM</h4>
      </div>
      <div class="card-content__cart">
          <div id="monev-chart"></div>
      </div>
    </div>
  </div>
</div>

<?php $__env->startPush('scripts'); ?>
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/modules/exporting.js"></script>
  <script src="<?php echo e(asset('public/js/module/main/chart-module.js')); ?>"></script>
<?php $__env->stopPush(); ?>
