<?php if(Auth::user()->level == 'admin'): ?>
  <?php echo $__env->make('partials.app.admin.adminmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
  <?php echo $__env->make('partials.app.user.usermenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>
