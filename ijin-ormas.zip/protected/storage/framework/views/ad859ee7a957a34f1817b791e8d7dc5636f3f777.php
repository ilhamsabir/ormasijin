<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Perijinan ORMAS/LSM Kota Bandung</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" data-id="<?php echo e(Auth::user()->id); ?>"/>

  <?php echo $__env->make('app.styles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/datareg.css')); ?>">
  <?php echo $__env->yieldPushContent('app.styles'); ?>
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini" style="background-color: #FAFBFC;">


  <!-- Header  -->
  <?php echo $__env->make('app.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="jumbotron jumbotron-custom">
    <div class="container">
      <?php if( Auth::user()->level == 'admin' ): ?>

        <?php echo $__env->make('app.partials.admin-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php else: ?>

        <?php echo $__env->make('app.partials.user-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php endif; ?>

    </div>
  </div>

  <!-- Content  -->
  <?php echo $__env->yieldContent('content'); ?>

  <!-- Footer -->
  <?php echo $__env->make('app.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


  <!-- Java script -->
  <?php echo $__env->make('app.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src="<?php echo e(asset('public/js/module/app/app.js')); ?>"></script>
    <script src="<?php echo e(asset('public/js/module/app/datareg.js')); ?>"></script>
  <?php echo $__env->yieldPushContent('app.scripts'); ?>
</body>
</html>
