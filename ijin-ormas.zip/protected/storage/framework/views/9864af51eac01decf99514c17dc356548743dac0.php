<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Perjininan ORMAS / LSM KOTA BANDUNG</title>
    <!-- Style -->
    <?php echo $__env->make('styles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/css/main.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <!-- Header  -->
    <?php echo $__env->make('partials.main.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Menu -->
    <?php echo $__env->make('partials.main.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Content  -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- Footer -->
    <?php echo $__env->make('partials.main.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Java script -->
    <?php echo $__env->make('scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
      <script src="<?php echo e(asset('public/js/global.js')); ?>"></script>
</body>
</html>
