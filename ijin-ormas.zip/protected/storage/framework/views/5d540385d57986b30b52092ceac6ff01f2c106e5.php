<?php $__env->startSection('content'); ?>

<div class="container container-app">
  <div class="row">
    <div class="col-md-12 card-table">
      <div class="ibox chat-view">
            <div class="ibox-content">
                <div class="row">
                  <div class="col-md-12 ">
                    <div class="chat-discussion">
                    <?php foreach($data as $key): ?>
                      <?php if(($key->toidpesan) === (Auth::user()->id) ): ?>
                        <div class="chat-message left">
            							<img class="message-avatar" src="../../public/img/cs1.png" alt="">
            							<div class="message">
            									<a class="message-author" href="#"> <?php echo e($key->name); ?></a>
            									<span class="message-date"> <?php echo e($key->pesancreated_at); ?></span>
            									<span class="message-content"><?php echo e($key->isipesan); ?> </span>
            							</div>
            						</div>
                      <?php else: ?>
                      <div class="chat-message right">
            							<img class="message-avatar" id="pesan-user-admin-detail" data-id="<?php echo e($key->fromidpesan); ?>" src="../../public/img/user.png" alt="">
                          <div class="message">
                              <a class="message-author" href="#"> <?php echo e($key->name); ?></a>
                              <span class="message-date"> <?php echo e($key->pesancreated_at); ?></span>
                              <span class="message-content"><?php echo e($key->isipesan); ?> </span>
                          </div>
            					</div>
                      <?php endif; ?>
                    <?php endforeach; ?>
                    </div>
                    <div class="chat-form">
                      <form class="" action="<?php echo e(url('admin/adminsendpesan')); ?>" method="post">
                          <?php echo e(csrf_field()); ?>

                        <div class="col-lg-10">
                            <div class="form-group">
                                <input type="hidden" name="toid" value="" id="toid-from-admin">
                                <textarea class="form-control " name="isi" placeholder="Enter message text"></textarea>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="form-group">
                                <button type="submit" class="btn btn-success btn-lg message-input" name="button"><i class="fa fa-paper-plane-o"></i> Send</button>
                            </div>
                        </div>
                      </form>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>