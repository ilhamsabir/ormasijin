<div class="col-md-12">
  <div class=" data-card">
    <h2>Data Personal</h2>
    <table class="table table-striped" width="330">
      <tr>
        <td width="60">Nama</td>
        <td width="120"><?php echo e($row->name); ?></td>
      </tr>
      <tr>
        <td width="60">Alamat</td>
        <td width="120"><?php echo e($row->alamat); ?></td>
      </tr>
      <tr>
        <td width="60">No Handphone</td>
        <td width="120"><?php echo e($row->no_tlp); ?></td>
      </tr>
      <tr>
        <td width="60">Email</td>
        <td width="120"><?php echo e($row->email); ?></td>
      </tr>
    </table>
  </div>
</div>

<div class="col-md-12">
  <div class="data-card">
    <h2>Data Organisasi</h2>
    <table class="table table-striped">
      <tr>
        <td width="60">Nama organisasi</td>
        <td width="120"><?php echo e($row->namaorganisasi); ?></td>
      </tr>
      <tr>
        <td width="60">Bidang kegiatan</td>
        <td width="120"><?php echo e($row->bidangkegiatan); ?></td>
      </tr>
      <tr>
        <td width="60">Ruang lingkup</td>
        <td width="120"><?php echo e($row->ruanglingkup); ?></td>
      </tr>
      <tr>
        <td width="60">Alamat</td>
        <td width="120"><?php echo e($row->alamatsekretarian); ?></td>
      </tr>
      <tr>
        <td width="60">Tempat, tanggal pendirian</td>
        <td width="120"><?php echo e($row->tempatpendirian); ?>, <?php echo e($row->waktupendirian); ?></td>
      </tr>
      <tr>
        <td width="60">Asas organisasi</td>
        <td width="120"><?php echo e($row->asasorganisasi); ?></td>
      </tr>
      <tr>
        <td width="60">Tujuan organisasi</td>
        <td width="120"><?php echo e($row->tujuanorganisasi); ?></td>
      </tr>
    </table>
  </div>
</div>

<div class="col-md-12">
  <div class="data-card">
    <h2>Data Kepengurusan</h2>
    <table class="table table-striped">
      <tr>
        <td width="60">Nama pendiri</td>
        <td width="120"><?php echo e($row->namapendiri); ?></td>
      </tr>
      <tr>
        <td width="60">Nama penasehat</td>
        <td width="120"><?php echo e($row->namapenasehat); ?></td>
      </tr>
      <tr>
        <td width="60">Nama pembina</td>
        <td width="120"><?php echo e($row->namapembina); ?></td>
      </tr>
    </table>
  </div>
</div>

<div class="col-md-12">
  <div class="data-card">
    <h2>Data Ketua</h2>
    <table class="table table-striped">
      <tr>
        <td width="60">Nama </td>
        <td width="120"><?php echo e($row->namaketua); ?></td>
      </tr>
      <tr>
        <td width="60">Tempat, tanggal lahir</td>
        <td width="120"><?php echo e($row->tempatlahirketua); ?>, <?php echo e($row->tgllahirketua); ?></td>
      </tr>
      <tr>
        <td width="60">Jenis kelamin</td>
        <td width="120"><?php echo e($row->jeniskelaminketua); ?></td>
      </tr>
      <tr>
        <td width="60">Agama</td>
        <td width="120"><?php echo e($row->agamaketua); ?></td>
      </tr>
      <tr>
        <td width="60">Status pernikahan</td>
        <td width="120"><?php echo e($row->statusketua); ?></td>
      </tr>
      <tr>
        <td width="60">Pendidikan</td>
        <td width="120"><?php echo e($row->pendidikanketua); ?></td>
      </tr>
      <tr>
        <td width="60">No Hp</td>
        <td width="120"><?php echo e($row->nohpketua); ?></td>
      </tr>
      <tr>
        <td width="60">Email</td>
        <td width="120"><?php echo e($row->emailketua); ?></td>
      </tr>
    </table>
  </div>
</div>

<div class="col-md-12">
  <div class="data-card">
    <h2>Data Sekretaris</h2>
    <table class="table table-striped">
      <tr>
        <td width="60">Nama </td>
        <td width="120"><?php echo e($row->namasekretaris); ?></td>
      </tr>
      <tr>
        <td width="60">Tempat, tanggal lahir</td>
        <td width="120"><?php echo e($row->tempatlahirsekretaris); ?>, <?php echo e($row->tgllahirsekretaris); ?></td>
      </tr>
      <tr>
        <td width="60">Jenis kelamin</td>
        <td width="120"><?php echo e($row->jeniskelaminsekretaris); ?></td>
      </tr>
      <tr>
        <td width="60">Agama</td>
        <td width="120"><?php echo e($row->agamasekretaris); ?></td>
      </tr>
      <tr>
        <td width="60">Status pernikahan</td>
        <td width="120"><?php echo e($row->statussekretaris); ?></td>
      </tr>
      <tr>
        <td width="60">Pendidikan</td>
        <td width="120"><?php echo e($row->pendidikansekretaris); ?></td>
      </tr>
      <tr>
        <td width="60">No Hp</td>
        <td width="120"><?php echo e($row->nohpsekretaris); ?></td>
      </tr>
      <tr>
        <td width="60">Email</td>
        <td width="120"><?php echo e($row->emailsekretaris); ?></td>
      </tr>
    </table>
  </div>
</div>

<div class="col-md-12">
  <div class="data-card">
    <h2>Data Bendahara</h2>
    <table class="table table-striped">
      <tr>
        <td width="60">Nama </td>
        <td width="120"><?php echo e($row->namabendahara); ?></td>
      </tr>
      <tr>
        <td width="60">Tempat, tanggal lahir</td>
        <td width="120"><?php echo e($row->tempatlahirbendahara); ?>, <?php echo e($row->tgllahirbendahara); ?></td>
      </tr>
      <tr>
        <td width="60">Jenis kelamin</td>
        <td width="120"><?php echo e($row->jeniskelaminbendahara); ?></td>
      </tr>
      <tr>
        <td width="60">Agama</td>
        <td width="120"><?php echo e($row->agamabendahara); ?></td>
      </tr>
      <tr>
        <td width="60">Status pernikahan</td>
        <td width="120"><?php echo e($row->statusbendahara); ?></td>
      </tr>
      <tr>
        <td width="60">Pendidikan</td>
        <td width="120"><?php echo e($row->pendidikanbendahara); ?></td>
      </tr>
      <tr>
        <td width="60">No Hp</td>
        <td width="120"><?php echo e($row->nohpbendahara); ?></td>
      </tr>
      <tr>
        <td width="60">Email</td>
        <td width="120"><?php echo e($row->emailbendahara); ?></td>
      </tr>
    </table>
  </div>
</div>
