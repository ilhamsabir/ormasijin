<div class="form-group">
   <label class="col-md-4 control-label">Nama Pendiri Organisasi</label>
   <div class="col-md-8 margin-bottom--20">
     <input class="form-control" type="text" name="namapendiri" value="<?php echo e($key->namapendiri); ?>" required>
   </div>
 </div>

<div class="form-group">
 <label class="col-md-4 control-label">Nama Pembina Organisasi <font color="red">&nbsp;*</font></label>
 <div class="col-md-8 margin-bottom--20">
   <input class="form-control" type="text" name="namapembina" value="<?php echo e($key->namapembina); ?>" required>
 </div>
</div>

<div class="form-group">
   <label class="col-md-4 control-label">Nama Penasehat Organisasi <font color="red">&nbsp;*</font></label>
   <div class="col-md-8 margin-bottom--20">
     <input class="form-control" type="text" name="namapenasehat" value="<?php echo e($key->namapenasehat); ?>" required>

   </div>
 </div>


  <!-- Ketua -->
  <h4 class="biodata">Biodata Ketua</h4>
   <div class="form-group">
       <label class="col-md-4 control-label">Nama <font color="red">&nbsp;*</font></label>
        <div class="col-md-8 margin-bottom--20">
           <input type="text" class="form-control" name="namaketua" value="<?php echo e($key->namaketua); ?>" required/>
        </div>
   </div>
   <div class="form-group">
       <label class="col-md-4 control-label">Gelar </label>
        <div class="col-md-8 margin-bottom--20">
           <input type="text" class="form-control" name="gelarketua" value="<?php echo e($key->gelarketua); ?>"/>
        </div>
   </div>
   <div class="form-group">
       <label class="col-md-4 control-label">Nama Panggilan </label>
        <div class="col-md-8 margin-bottom--20">
           <input type="text" class="form-control" name="panggilanketua" value="<?php echo e($key->panggilanketua); ?>"/>
        </div>
   </div>
   <div class="form-group">
     <label class="col-md-4 control-label">Tempat & Tanggal Lahir </label>
      <div class="col-xs-4 margin-bottom--20">
         <input type="text" class="form-control" name="tempatlahirketua" value="<?php echo e($key->tempatlahirketua); ?>"/>
      </div>
      <div class="col-md-4 margin-bottom--20">
      <div id="dp-ex-3" class="input-group date" data-auto-close="true" data-date="12-02--2016" data-date-format="dd-mm-yyyy" data-date-autoclose="true">
           <input class="form-control tgl-lahir-ketua" type="text" name="tgllahirketua" value="<?php echo e($key->tgllahirketua); ?>" readonly/>
           <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
       </div>
     </div> <!-- /.col -->

   </div>
   <div class="form-group">
     <label class="col-md-4 control-label">Jenis Kelamin </label>
      <div class="col-md-8 margin-bottom--20">
      <select class="form-control" name="jeniskelaminketua">
        <option value="<?php echo e($key->jeniskelaminketua); ?>"><?php echo e($key->jeniskelaminketua); ?></option>
        <option value="pria">Laki - laki</option>
        <option value="wanita">Perempuan</option>
      </select>
      </div>
   </div>
   <div class="form-group">
       <label class="col-md-4 control-label">Pendidikan </label>
        <div class="col-md-8 margin-bottom--20">
            <select class="form-control" name="pendidikanketua">
                <option value="<?php echo e($key->pendidikanketua); ?>"><?php echo e($key->pendidikanketua); ?></option>
                <option value="S3">S3</option>
                <option value="S2">S2</option>
                <option value="S1">S1</option>
                <option value="SMA">SMA</option>
                <option value="SMP">SMP</option>
                <option value="SD">SD</option>
           </select>
        </div>
   </div>

    <div class="form-group">
       <label class="col-md-4 control-label">Agama </label>
        <div class="col-md-8 margin-bottom--20">

             <select class="form-control" name="agamaketua">
                 <option value="<?php echo e($key->agamaketua); ?>"><?php echo e($key->agamaketua); ?></option>
                 <option value="Islam">Islam</option>
                 <option value="Kristen Protestan">Kristen Protestan</option>
                 <option value="Kristen Katolik">Kristen Katolik</option>
                 <option value="Budha">Budha</option>
                 <option value="Hindu">Hindu</option>
             </select>
        </div>
   </div>
   <div class="form-group">
       <label class="col-md-4 control-label">Status Pernikahan </label>
        <div class="col-md-8 margin-bottom--20">
        <select class="form-control" name="statusketua" id="s2_basic">
          <option value="<?php echo e($key->statusketua); ?>"><?php echo e($key->statusketua); ?></option>
          <option value="menikah">Menikah</option>
          <option value="belum">Belum Menikah</option>
        </select>
        </div>
   </div>

    <div class="form-group">
       <label class="col-md-4 control-label">No Hp</label>
        <div class="col-md-8 margin-bottom--20">
           <input type="text" class="form-control" name="nohpketua" value="<?php echo e($key->nohpketua); ?>"/>
        </div>
   </div>

    <div class="form-group">
       <label class="col-md-4 control-label">Email </label>
        <div class="col-md-8 margin-bottom--20">
           <input type="email" class="form-control" name="emailketua" value="<?php echo e($key->emailketua); ?>" />
        </div>
   </div>


   <!-- Sekretaris -->
    <h4 class="biodata">Biodata Sekretaris</h4>
    <div class="form-group">
       <label class="col-md-4 control-label">Nama <font color="red">&nbsp;*</font></label>
        <div class="col-md-8 margin-bottom--20">
           <input type="text" class="form-control" name="namasekretaris" value="<?php echo e($key->namasekretaris); ?>" required/>
        </div>
   </div>
   <div class="form-group">
       <label class="col-md-4 control-label">Gelar </label>
        <div class="col-md-8 margin-bottom--20">
           <input type="text" class="form-control" name="gelarsekretaris" value="<?php echo e($key->gelarsekretaris); ?>"/>
        </div>
   </div>
   <div class="form-group">
       <label class="col-md-4 control-label">Nama Panggilan </label>
        <div class="col-md-8 margin-bottom--20">
           <input type="text" class="form-control" name="panggilansekretaris" value="<?php echo e($key->panggilansekretaris); ?>"/>
        </div>
   </div>
   <div class="form-group">
       <label class="col-md-4 control-label">Tempat & Tanggal Lahir </label>
        <div class="col-xs-4 margin-bottom--20">
           <input type="text" class="form-control" name="tempatlahirsekretaris" value="<?php echo e($key->tempatlahirsekretaris); ?>" />
        </div>
   <div class="col-md-4 margin-bottom--20">
      <div id="dp-ex-4" class="input-group date" data-auto-close="true" data-date="12-02--2016" data-date-format="dd-mm-yyyy" data-date-autoclose="true">
           <input class="form-control tgl-lahir-bendahara" type="text" name="tgllahirsekretaris" value="<?php echo e($key->tgllahirsekretaris); ?>" readonly/>
           <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
       </div>

       </div> <!-- /.col -->

   </div>

    <div class="form-group">
       <label class="col-md-4 control-label">Jenis Kelamin </label>
        <div class="col-md-8 margin-bottom--20">
        <select class="form-control" name="jeniskelaminsekretaris">
          <option value="<?php echo e($key->jeniskelaminsekretaris); ?>"><?php echo e($key->jeniskelaminsekretaris); ?></option>
          <option value="pria">Laki - laki</option>
          <option value="wanita">Perempuan</option>
        </select>

        </div>
   </div>

   <div class="form-group">
       <label class="col-md-4 control-label">Pendidikan </label>
        <div class="col-md-8 margin-bottom--20">
            <select class="form-control" name="pendidikansekretaris">
                <option value="<?php echo e($key->pendidikansekretaris); ?>"><?php echo e($key->pendidikansekretaris); ?></option>
                <option value="S3">S3</option>
                <option value="S2">S2</option>
                <option value="S1">S1</option>
                <option value="SMA">SMA</option>
                <option value="SMP">SMP</option>
                <option value="SD">SD</option>
           </select>
        </div>
   </div>

    <div class="form-group">
       <label class="col-md-4 control-label">Agama </label>
        <div class="col-md-8 margin-bottom--20">

             <select class="form-control" name="agamasekretaris">
                 <option value="<?php echo e($key->agamasekretaris); ?>"><?php echo e($key->agamasekretaris); ?></option>
                 <option value="Islam">Islam</option>
                 <option value="Kristen Protestan">Kristen Protestan</option>
                 <option value="Kristen Katolik">Kristen Katolik</option>
                 <option value="Budha">Budha</option>
                 <option value="Hindu">Hindu</option>
             </select>
        </div>
   </div>

   <div class="form-group">
       <label class="col-md-4 control-label">Status Pernikahan </label>
        <div class="col-md-8 margin-bottom--20">
        <select id="s2_basic" class="form-control" name="statussekretaris" >
          <option value="<?php echo e($key->statussekretaris); ?>"><?php echo e($key->statussekretaris); ?></option>
          <option value="menikah">Menikah</option>
          <option value="belum">Belum Menikah</option>
        </select>

        </div>
   </div>

    <div class="form-group">
       <label class="col-md-4 control-label">No Hp</label>
        <div class="col-md-8 margin-bottom--20">
           <input type="text" class="form-control" name="nohpsekretaris" value="<?php echo e($key->nohpsekretaris); ?>" />
        </div>
   </div>

    <div class="form-group">
       <label class="col-md-4 control-label">Email </label>
        <div class="col-md-8 margin-bottom--20">
           <input type="email" class="form-control" name="emailsekretaris" value="<?php echo e($key->emailsekretaris); ?>"/>
        </div>
   </div>

   <!-- Bendahara -->
    <h4 class="biodata">Biodata Bendahara</h4>
    <div class="form-group">
       <label class="col-md-4 control-label">Nama <font color="red">&nbsp;*</font></label>
        <div class="col-md-8 margin-bottom--20">
           <input type="text" class="form-control" name="namabendahara" value="<?php echo e($key->namabendahara); ?>" required/>
        </div>
   </div>
   <div class="form-group">
       <label class="col-md-4 control-label">Gelar </label>
        <div class="col-md-8 margin-bottom--20">
           <input type="text" class="form-control" name="gelarbendahara" value="<?php echo e($key->gelarbendahara); ?>"/>
        </div>
   </div>
   <div class="form-group">
       <label class="col-md-4 control-label">Nama Panggilan </label>
        <div class="col-md-8 margin-bottom--20">
           <input type="text" class="form-control" name="panggilanbendahara" value="<?php echo e($key->panggilanbendahara); ?>"/>
        </div>
   </div>
   <div class="form-group">
       <label class="col-md-4 control-label">Tempat & Tanggal Lahir </label>
        <div class="col-xs-4 margin-bottom--20">
           <input type="text" class="form-control" name="tempatlahirbendahara" value="<?php echo e($key->tempatlahirbendahara); ?>"/>
        </div>
       <div class="col-md-4 margin-bottom--20">
        <div id="dp-ex-4" class="input-group date" data-auto-close="true" data-date="12-02--2016" data-date-format="dd-mm-yyyy" data-date-autoclose="true">
             <input class="form-control tgl-lahir-bendahara" type="text" name="tgllahirbendahara" value="<?php echo e($key->tgllahirbendahara); ?>" readonly/>
             <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
         </div>
       </div> <!-- /.col -->
   </div>

    <div class="form-group">
       <label class="col-md-4 control-label">Jenis Kelamin </label>
        <div class="col-md-8 margin-bottom--20">
        <select class="form-control" name="jeniskelaminbendahara">
          <option value="<?php echo e($key->jeniskelaminbendahara); ?>"><?php echo e($key->jeniskelaminbendahara); ?></option>
          <option value="pria">Laki - laki</option>
          <option value="wanita">Perempuan</option>
        </select>

        </div>
   </div>

    <div class="form-group">
       <label class="col-md-4 control-label">Pendidikan </label>
        <div class="col-md-8 margin-bottom--20">
            <select class="form-control" name="pendidikanbendahara">
                <option value="<?php echo e($key->pendidikanbendahara); ?>"><?php echo e($key->pendidikanbendahara); ?></option>
                <option value="S3">S3</option>
                <option value="S2">S2</option>
                <option value="S1">S1</option>
                <option value="SMA">SMA</option>
                <option value="SMP">SMP</option>
                <option value="SD">SD</option>
           </select>
        </div>
   </div>

    <div class="form-group">
       <label class="col-md-4 control-label">Agama </label>
        <div class="col-md-8 margin-bottom--20">
             <select class="form-control" name="agamabendahara">
                 <option value="<?php echo e($key->agamabendahara); ?>"><?php echo e($key->agamabendahara); ?></option>
                 <option value="Islam">Islam</option>
                 <option value="Kristen Protestan">Kristen Protestan</option>
                 <option value="Kristen Katolik">Kristen Katolik</option>
                 <option value="Budha">Budha</option>
                 <option value="Hindu">Hindu</option>
             </select>
        </div>
   </div>

   <div class="form-group">
       <label class="col-md-4 control-label">Status Pernikahan </label>
        <div class="col-md-8 margin-bottom--20">
        <select id="s2_basic" class="form-control" name="statusbendahara" >
          <option value="<?php echo e($key->statusbendahara); ?>"><?php echo e($key->statusbendahara); ?></option>
          <option value="menikah">Menikah</option>
          <option value="belum">Belum Menikah</option>
        </select>

        </div>
   </div>

    <div class="form-group">
       <label class="col-md-4 control-label">No Hp</label>
        <div class="col-md-8 margin-bottom--20">
           <input type="text" class="form-control" value="<?php echo e($key->nohpbendahara); ?>" name="nohpbendahara" />
        </div>
   </div>

    <div class="form-group">
       <label class="col-md-4 control-label">Email </label>
        <div class="col-md-8 margin-bottom--20">
           <input type="email" class="form-control" name="emailbendahara" value="<?php echo e($key->emailbendahara); ?>"/>
        </div>
   </div>

   <!--Kepengurusan -->

   <div class="form-group">
       <label class="col-md-4 control-label">Masa Bhakti Kepengurusan<font color="red">&nbsp;*</font></label>
        <div class="col-md-8 margin-bottom--20">
           <input type="text" class="form-control" name="masabakti" value="<?php echo e($key->masabakti); ?>" required/>
        </div>
   </div>

  <div class="form-group">
       <label class="col-md-4 control-label">Keputusan Tertinggi Organisasi<font color="red">&nbsp;*</font></label>
        <div class="col-md-8 margin-bottom--20">
           <input type="text" class="form-control" name="keputusantertinggi" value="<?php echo e($key->keputusantertinggi); ?>" required/>
        </div>
   </div>

<div class="form-group">
  <label class="col-md-4 control-label">Unit / Satuan / Organisasi<font color="red">&nbsp;*</font></label>
  <div class="col-md-8 margin-bottom--20">
     <input type="text" class="form-control" name="unit" value="<?php echo e($key->unit); ?>" required/>
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label">Usaha Organisasi<font color="red">&nbsp;*</font></label>
  <div class="col-md-8 margin-bottom--20">
     <input type="text" class="form-control" name="usaha" value="<?php echo e($key->usaha); ?>" required/>
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label">Sumber Keuangan<font color="red">&nbsp;*</font></label>
  <div class="col-md-8 margin-bottom--20">
     <input type="text" class="form-control" name="sumberkeuangan" value="<?php echo e($key->sumberkeuangan); ?>" required/>
  </div>
</div>
