<?php $__env->startPush('app.styles'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('public/css/datareg.css')); ?>">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css"/>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<h1>
			Blank page
			<small>it all starts here</small>
		</h1>
		<ol class="breadcrumb">
			<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
			<li><a href="#">Examples</a></li>
			<li class="active">Blank page</li>
		</ol>
	</section>

	<!-- Main content -->
	<section class="content">

		<!-- Default box -->
		<div class="box">
			<div class="box-header with-border">
				<h3 class="box-title">Title</h3>
			</div>
			<div class="box-body">
        <table id="example" class="stripe cell-border" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Extn.</th>
                <th>Start date</th>
                <th>Salary</th>
            </tr>
        </thead>
    </table>
      </div>
			<!-- /.box-body -->
			<div class="box-footer">
				Footer
			</div>
			<!-- /.box-footer-->
		</div>
		<!-- /.box -->

	</section>
	<!-- /.content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('app.scripts'); ?>
  <script type="text/javascript" src="https://cdn.datatables.net/v/bs-3.3.7/jq-2.2.4/pdfmake-0.1.18/dt-1.10.13/b-1.2.4/b-html5-1.2.4/fc-3.2.2/fh-3.1.2/sc-1.4.2/se-1.2.0/datatables.min.js"></script>
  <script src="<?php echo e(asset('public/js/module/app/datareg.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('app.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>