<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Perijinan</title>

    <?php echo $__env->make('styles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/css/vendor/styles.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/css/app.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>

</head>
<body>
  <!-- Header  -->
  <?php echo $__env->make('partials.app.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="col-sm-12">
      <div class="row">
        <!-- Menu -->
        <?php echo $__env->make('partials.app.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Content  -->
        <?php echo $__env->yieldContent('content'); ?>
      </div>
  </div>

  <!-- Footer -->
  <?php echo $__env->make('partials.app.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- Java script -->
  <?php echo $__env->make('scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldPushContent('scripts'); ?>
  

</body>
</html>
