<ul class="nav">
  <li class="active">
  <a href="/"><i class="fa fa-home"></i> Dashboard</a>
  </li>

  <li>
  <a href="/todoone"><i class="fa fa-code"></i> Admin</a>
  </li>

  <li>
  <a href="/onchange"><i class="fa fa-code"></i> OnChange</a>
  </li>

  <li>
  <a href="/onchangevue"><i class="fa fa-code"></i> OnChange VUE Js</a>
  </li>
</ul>
