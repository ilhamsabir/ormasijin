<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container no-padding">
      <div class="row">
          <div class="col-md-12">
            <div class="card">
              <h2>Alur</h2>
            </div>
          </div>
      </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>