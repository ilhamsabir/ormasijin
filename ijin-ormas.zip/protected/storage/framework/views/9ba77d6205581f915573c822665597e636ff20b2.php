<?php $__env->startSection('content'); ?>
<section class="content">
  <div class="container no-padding">
      <div class="row">
          <!-- NEws Components -->
          <?php echo $__env->make('components.main.berita', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <!-- Login components -->
          <?php echo $__env->make('components.main.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      </div>
  </div>
</section>

<section class="content">
  <div class="container no-padding">
      <div class="row">
          <div class="col-md-4 no-padding">
            <!-- Monitoring components -->
            <?php echo $__env->make('components.main.monitoring', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <!-- Alamat components -->
            <?php echo $__env->make('components.main.alamat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>
          <!-- Chart components -->
          <?php echo $__env->make('components.main.chart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>