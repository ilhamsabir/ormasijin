<table class="table table-striped">
<tbody>
<tr>
<td style="width: 199px;">Nama Organisasi</td>
<td style="width: 262px;">: <?php echo e($row->namaorganisasi); ?></td>
</tr>
<tr>
<td style="width: 199px;">Bidang Kegiatan</td>
<td style="width: 262px;">: <?php echo e($row->bidangkegiatan); ?></td>
</tr>
<tr>
<td style="width: 199px;">Ruang Lingkup</td>
<td style="width: 262px;">: <?php echo e($row->ruanglingkup); ?></td>
</tr>
<tr>
<td style="width: 199px;">Asas Organisasi</td>
<td style="width: 262px;">: <?php echo e($row->asasorganisasi); ?></td>
</tr>
<tr>
<td style="width: 199px;">Tujuan Organisasi</td>
<td style="width: 262px;">: <?php echo e($row->tujuanorganisasi); ?></td>
</tr>
<tr>
<td style="width: 199px;">Tanggal Pendirian</td>
<td style="width: 262px;">: <?php echo e($row->waktupendirian); ?></td>
</tr>
<tr>
<td style="width: 199px;">Tempat Pendirian</td>
<td style="width: 262px;">: <?php echo e($row->tempatpendirian); ?></td>
</tr>
<tr>
<td style="width: 199px;">Alamat Sekretariat</td>
<td style="width: 262px;">: <?php echo e($row->alamatsekretarian); ?></td>
</tr>
</tbody>
</table>
