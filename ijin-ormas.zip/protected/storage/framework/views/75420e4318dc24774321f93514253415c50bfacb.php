<script src="<?php echo e(asset('public/js/vendor/jquery-1.11.2.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/vendor/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/vendor/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/vendor/bootstrap-datepicker.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/locale/id.js"></script>
<script src="<?php echo e(asset('public/js/vendor/select2.min.js')); ?>"></script>
